import RPi.GPIO as GPIO
import time
from DRV8825 import DRV8825
import random
import os

GPIO.setmode(GPIO.BCM)

# Define GPIO pins for the end stops
end_stop_pins = [17,27]  # Adjust these pins based on your wiring


total = 5000

for end_stop_pin in end_stop_pins:
    GPIO.setup(end_stop_pin, GPIO.IN)

try:
    Motor1 = DRV8825(dir_pin=13, step_pin=19, enable_pin=12, mode_pins=(16, 17, 20))
    Motor2 = DRV8825(dir_pin=24, step_pin=18, enable_pin=4, mode_pins=(21, 22, 27))

    # for a in range(0, 50):
    #    Motor1.SetMicroStep('hardward', 'halfstep')
    #    Motor1.TurnStep(Dir='forward', steps=random.randrange(10, 5000, 1), stepdelay=0.000001)

    while all(GPIO.input(pin) == GPIO.LOW for pin in end_stop_pins):
        Motor1.SetMicroStep('hardward', 'halfstep')
        Motor1.TurnStep(Dir='forward', steps=1, stepdelay=0.000001)
        # Motor1.Stop()


    # Take picture at bottom
    index = 1
    os.system("libcamera-still --output pics/image" + str(index) + ".jpg")
    os.system("./aws_upload")
    index = index + 1

    Motor1.TurnStep(Dir='backward', steps=5000, stepdelay=0.000001)

    count = 5000
    # Take picture every fourth section
    while all(GPIO.input(pin) == GPIO.LOW for pin in end_stop_pins):
       while all(GPIO.input(pin) == GPIO.LOW for pin in end_stop_pins):
          Motor1.TurnStep(Dir='backward', steps=1, stepdelay=0.000001)
          count = count + 1
          total = total + 1
          if (count > 24105):
              break
       os.system("libcamera-still --output pics/image" + str(index) + ".jpg")
       os.system("./aws_upload")
       index = index + 1
       if (index == 5):
           index = 1
       count = 0

    print("total: " + str(total))
except KeyboardInterrupt:
    pass
finally:
    # Clean up GPIO on exit
    GPIO.cleanup()
    print("GPIO cleanup completed.")





