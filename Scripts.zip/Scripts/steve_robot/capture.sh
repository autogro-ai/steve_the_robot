#!/bin/bash

# Capture an image using libcamera-still
libcamera-still --output ~/robot_pics/image1.jpg

# Upload the captured image to AWS S3
aws s3 cp ~/robot_pics/image1.jpg s3://autogro-device-images/inbound/devices/1/
