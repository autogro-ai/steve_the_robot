# AutoGro Motor code
#
# V1 2-13-24   Initial development work
#

import RPi.GPIO as GPIO
import time
from DRV8825 import DRV8825

GPIO.setmode(GPIO.BCM)

################### Constants ############################################
VERSION = 1          # Version of code
END_STOP1 = 27       # End stop GPIO pin for first motor
END_STOP2 = 17       # End stop GPIO pin for second motor
MOTOR_DELAY = 0      # Seconds between motor steps
MAX_COUNT = 10000    # Max forward step counts
MAX_COUNT2 = 2500    # Max forwared for second motor after first MAX_COUNT
###########################################################################

# Setup end-stop pins as GPIO input
GPIO.setup(END_STOP1, GPIO.IN)
GPIO.setup(END_STOP2, GPIO.IN)

print("AutoGro Motor Code version: " + str(VERSION))

try:
   Motor1 = DRV8825(dir_pin=13, step_pin=19, enable_pin=12, mode_pins=(16, 17, 20))
   Motor2 = DRV8825(dir_pin=24, step_pin=18, enable_pin=4, mode_pins=(21, 22, 27))

########## Seek to the first endstop
   print("Homming the robot")
   Motor1.SetMicroStep('hardware','halfstep')
   Motor2.SetMicroStep('hardware','halfstep')

   while(GPIO.input(END_STOP1) == GPIO.LOW or GPIO.input(END_STOP2) == GPIO.LOW):
      if (GPIO.input(END_STOP1) == GPIO.LOW):
         Motor1.TurnStep(Dir='forward',steps=1,stepdelay=.000001)
         print("First end-stop not tripped")
      if (GPIO.input(END_STOP2) == GPIO.LOW):
         Motor2.TurnStep(Dir='backward',steps=1,stepdelay=.000001)
         print("Second end-stop not tripped")
      time.sleep(MOTOR_DELAY)

   print("Robot initial home complete")

############ Test forward arm movement
   cnt = 0
   while(cnt < MAX_COUNT):
      Motor1.TurnStep(Dir='backward',steps=1,stepdelay=.000001)
      Motor2.TurnStep(Dir='forward',steps=1, stepdelay=.000001)
      print("Step forward")
      time.sleep(MOTOR_DELAY)
      cnt = cnt + 1

   cnt = 0
   while(cnt < MAX_COUNT2):
      Motor2.TurnStep(Dir='forward',steps=1, stepdelay=.000001)
      print("Second motor step forward")
      time.sleep(MOTOR_DELAY)
      cnt = cnt + 1

   print("Robot second home complete")


   Motor1.Stop()
   Motor2.Stop()

except KeyboardInterrupt:
   pass
finally:
    # Clean up GPIO on exit
   GPIO.cleanup()
   print("GPIO cleanup completed.")
