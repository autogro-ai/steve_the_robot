import RPi.GPIO as GPIO
import time
from DRV8825 import DRV8825
import random

# Set up GPIO mode
GPIO.setmode(GPIO.BCM)

# Define GPIO pins for the end stops
end_stop_pins = [17]  # Adjust these pins based on your wiring

# Set up GPIO pins for input with pull-up resistor
for end_stop_pin in end_stop_pins:
    GPIO.setup(end_stop_pin, GPIO.IN)

try:
    Motor1 = DRV8825(dir_pin=13, step_pin=19, enable_pin=12, mode_pins=(16, 17, 20))
    Motor2 = DRV8825(dir_pin=24, step_pin=18, enable_pin=4, mode_pins=(21, 22, 27))

    # for a in range(0, 50):
    #    Motor1.SetMicroStep('hardward', 'halfstep')
    #    Motor1.TurnStep(Dir='forward', steps=random.randrange(10, 5000, 1), stepdelay=0.000001)

    for a in range(0, 50):
        Motor1.SetMicroStep('hardward', 'halfstep')    
        Motor1.TurnStep(Dir='forward', steps=random.randrange(10, 5000, 1), stepdelay=0.000001)
        time.sleep(0.1)
        Motor1.TurnStep(Dir='backward', steps=random.randrange(10, 5000, 1), stepdelay=0.000001)
#        Motor1.Stop()

        # Wait for end stops to be clicked
        while all(GPIO.input(pin) == GPIO.LOW for pin in end_stop_pins):
            time.sleep(0.1)

        print("End stop clicked. Stopping motors.")
        Motor1.Stop()
        Motor2.Stop()
        exit()

        Motor1.TurnStep(Dir='backward', steps=random.randrange(10, 5000, 1), stepdelay=0.000001)
        Motor1.Stop()

except KeyboardInterrupt:
    pass
finally:
    # Clean up GPIO on exit
    GPIO.cleanup()
    print("GPIO cleanup completed.")
