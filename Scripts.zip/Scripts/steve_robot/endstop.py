import RPi.GPIO as GPIO
import time

# Set GPIO mode
GPIO.setmode(GPIO.BCM)

# Define GPIO pins for the end stops
end_stop_pins = [17, 27]  # Adjust these pins based on your wiring

# Set up GPIO pins for input with pull-up resistor
for pin in end_stop_pins:
    GPIO.setup(pin, GPIO.IN)

try:
    print("Waiting for end stops to be clicked...")

    while True:
        for pin in end_stop_pins:
            if GPIO.input(pin) == GPIO.HIGH:  # GPIO.LOW means the button is pressed
                print(f"End stop on GPIO pin {pin} clicked!")

        # Add a small delay to avoid high CPU usage
        time.sleep(0.1)

except KeyboardInterrupt:
    pass
finally:
    # Clean up GPIO on exit
    GPIO.cleanup()
    print("GPIO cleanup completed.")
