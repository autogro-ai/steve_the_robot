#!/bin/bash


# Set the source and destination information
SOURCE_FOLDER="$HOME/Scripts/"
DEST_BUCKET="autogro-backups"
SUBFOLDER="$(date +'%Y-%m-%d')/"

# Ensure the destination subfolder exists in S3
aws s3api put-object --bucket "$DEST_BUCKET" --key "$SUBFOLDER"

# Sync files from the source folder to the destination in S3
aws s3 sync "$SOURCE_FOLDER" "s3://$DEST_BUCKET/$SUBFOLDER"
